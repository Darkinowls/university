package lab6.interfaces;

import lab6.models.Watch;

public interface View {
    public void printData(Watch data);
    public void printTime(Watch time);
}
