package lab6.interfaces;

// Для патерну Command
public interface Command {
    public void execute();
}
