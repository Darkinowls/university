package lab6;

// enum від 0 до 11 для усіх місяців
public enum Month {
    January,
    February,
    March,
    April,
    May,
    June,
    July,
    August,
    September,
    October,
    November,
    December,
}
