package lab6.interfaces;

// константи для примітивних перевірок
public interface Consts {
int MAXHOUR = 23;
int MINHOUR = 0;

int MINMINUTE = 0;
int MAXMINUTE = 59;

int MINYEAR = 0;

int MINDAY = 1;
int MAXDAY = 31;

int MINMONTH = 1;
int MAXMONTH = 12;
}
