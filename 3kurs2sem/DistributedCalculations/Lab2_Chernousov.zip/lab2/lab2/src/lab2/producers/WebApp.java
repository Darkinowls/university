package lab2.producers;

public class WebApp extends Producer {
    public WebApp(String input) {
        super(input);
        source = "WebApp";
    }
}
