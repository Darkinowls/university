package lab2.producers;

public class Terminal extends Producer {
    public Terminal(String input) {
        super(input);
        source = "Terminal";
    }
}
