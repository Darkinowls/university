from collections import Counter


def count_words_in_files(files: list[str]) -> Counter:
    counter: Counter = Counter()
    for file in files:
        counter += Counter(file.splitlines())
    return counter


def merge_counters(counter1, counter2):
    return Counter(counter1) + Counter(counter2)
